
/**
 * Write a description of class Abeja here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Abeja
{
    double x;
    double y;
    boolean B=false;
    public Abeja(double x, double y){
        this.x=x;
        this.y=y;
        this.B=B;
    }
}
