import java.util.ArrayList;
import java.util.LinkedList;
//graficos
import java.util.*;
import java.awt.Color;
import java.awt.Graphics;
import javax.swing.JPanel;
import javax.swing.JFrame;
import java.util.Scanner;
import java.io.*;
public class Qtree extends JPanel
{
    public class Node
    {
        //cambiar todos los array por linked list
        //public Abeja data[];
        public boolean son = false; 
        public Node n1,n2,n3,n4;
        public LinkedList<Abeja> data;
        public Node()
        {
            n1=null;
            n2=null;
            n3=null;
            n4=null;
            data=new LinkedList<Abeja>();
        }

    }
    static JFrame frame;
    //boolean z=true;
    ArrayList<Abeja> lista=new ArrayList<Abeja>();//lista donde se se carga la lista de abejas iniciales
    private Node root;
    private int size;//lo mismo que data, se volvera un arreglo de tipo abeja
    public Qtree()
    {
        root=null;
    }

    public void listaAbejas(String archivo) throws FileNotFoundException, IOException {
        String cadena;
        FileReader f = new FileReader(archivo);
        BufferedReader b = new BufferedReader(f);
        int i=0;
        double xmin=000;
        double ymin=000;
        while((cadena = b.readLine())!=null) {
            i++;
            String[]parts=cadena.split(",");
            Abeja bee=new Abeja((-1)*(Double.parseDouble(parts[0])),Double.parseDouble(parts[1]));
            lista.add(bee);
            if(bee.x>xmin)xmin=bee.x;
            if(bee.y>ymin)ymin=bee.y;
           
        }
        System.out.println(xmin+"   "+ymin);
        b.close();
    }



    public double distancia(double x0,double x1,double y0,double y1 ){
        double x=(Math.pow((x0-x1),2));
        double y=(Math.pow((y0-y1),2));       
        double res=Math.sqrt(x+y);
        return res;
    }

    public void iniciar(){
        /*
        for(int i=0;i<100;i++){
        double x= Math.random()*1000;
        double y= Math.random()*1000;
        Abeja p=new Abeja(x,y);
        lista.add(p);
        }
         */
        Node n = new Node();
        root=n;
        //aqui se cargan las abejas
        try{
            listaAbejas("bee.TXT");
        }catch(Exception e){

            System.err.println("El archivo no existe.");
            System.exit(0);
        }
        //aqui se agregan las abejas, este es el codigo grande
        for(int i=0;i<lista.size();i++){
            Repartir(root,lista.get(i),75.5165542256,6.0,75.5925759068,6.36177301628);
        }
        //Recorrido(root,0,0,1000,1000);
       
        //aqui se calcula la distancia euclidiana de  cada abeja, hay que recorrer todo el arbol
        Comparar(root);
    }


    public void Comparar(Node k){

        if(k.data.size()>1  )auxC(k.data);
        if(k.n1!=null)Comparar(k.n1);
        if(k.n2!=null)Comparar(k.n2);
        if(k.n3!=null)Comparar(k.n3);
        if(k.n4!=null)Comparar(k.n4);

    }

    public void auxC(LinkedList<Abeja> a){
        for(int i=0;i<a.size();i++){
            for(int j=i+1;j<a.size();j++){
                double choque= distancia(a.get(i).x,a.get(j).x,a.get(i).y,a.get(j).y);
                if(choque<0.0005){
                    a.get(i).B=true;
                    a.get(j).B=true;
                }else{}

            }
        }

    }

    //estoy en duda si quitar el lvlx y lvly ya que estos los cree para dividir las coordenadas, pero creo que dividirlos por 2 basta
    public double Cuadrante(double a,double min,double max){
        //ln("cuadrante\n"+a+"\n"+min+"\n"+max+"\n min---max");
        //ln("mitaddd     "+(max-(max-min)/2));
        if(a>=min && a<=max){
            if(a/((max+min)/2)>=1 && a/((max+min)/2)<2){
                //ln("mitaddd     "+(max+min)/2);
                a=1;
            }else{a=0;}
            //ln("aaaaa "+a);
            return a;
        }
        return 2;
    }
    //esto es el recorrido de la lista de abejas
    public void Repartir(Node k,Abeja b,double xmin,double ymin,double xmax,double ymax){
        double cuadrantex= Cuadrante(b.x,xmin,xmax); 
        double cuadrantey= Cuadrante(b.y,ymin,ymax);
        //si el nodo no tiene hijos, y no se a llenado, se le agrega el elemento entra aqui
        //este no tiene casi nada
        if(k.data.size()<150 && k.n1==null && k.n2==null && k.n3==null && k.n4==null ){
            k.data.add(b);
            return;
        }else{}
        //si tiene hijos, y tiene al menos 1 elemento significa que se tiene que seguir bajando 
        //el dato, por lo tanto, se va a buscar a cual hijo se le debe asignar.
        //deberia tener complejidad baja, es solo buscar y agregarlo
        if(k.data.size()>=1 && (k.n1!=null || k.n2!=null || k.n3!=null || k.n4!=null)){
            double cuadrantexx= Cuadrante(k.data.get(0).x,xmin,xmax);
            double cuadranteyy= Cuadrante(k.data.get(0).y,ymin,ymax);
            if(cuadrantexx==0 && cuadranteyy==0){
                if(k.n1==null)k.n1=new Node();
                k.n1.data.add(k.data.pop());
                Repartir(k,b,xmin,ymin,xmax,ymax);
            }else if(cuadrantexx==1 && cuadranteyy==0){
                if(k.n2==null)k.n2=new Node();
                k.n2.data.add(k.data.pop());
                Repartir(k,b,xmin,ymin,xmax,ymax);
            }if(cuadrantexx==0 && cuadranteyy==1){
                if(k.n3==null)k.n3=new Node();
                k.n3.data.add(k.data.pop());
                Repartir(k,b,xmin,ymin,xmax,ymax);
            }if(cuadrantexx==1 && cuadranteyy==1){
                if(k.n4==null)k.n4=new Node();
                k.n4.data.add(k.data.pop());
                Repartir(k,b,xmin,ymin,xmax,ymax);
            }else{}
        }
  
        //aqui se hace casi todo, aqui se encuentra casi toda la complejidad
        //creo que es mlog(n), ya te toca a ti (esta complejidad es las mas importante)
        if(xmax-xmin>0){
            if(cuadrantex==0 && cuadrantey==0){
                if(k.n1==null)k.n1=new Node();
                Repartir(k.n1,b,xmin,ymin,(xmax+ymax)/2,(ymax+ymin)/2);
            }
            else if(cuadrantex==0 && cuadrantey==1){          
                if(k.n2==null)k.n2=new Node();
                Repartir(k.n2, b,xmin,(ymin+ymax)/2,(xmax+xmin)/2,ymax);

            }else if(cuadrantex==1 && cuadrantey==0){                  
                if(k.n3==null)k.n3=new Node();
                Repartir(k.n3, b,(xmin+xmax)/2,ymin,xmax,(ymax+ymin)/2);
            } else if(cuadrantex==1 && cuadrantey==1){
                if(k.n4==null)k.n4=new Node();
                Repartir(k.n4,b,(xmin+xmax)/2,(ymin+ymax)/2,xmax,ymax);
            }
        }else{}

    }

    public static void main(String[] args){
        //crear un arbol,
        Qtree n=new Qtree();

        n.iniciar(); //aqui se corre todo
        //la complejidad de lo que queda es n, siendo n el tamaño de la lista de abejas que nos pasaron
        frame = new JFrame("bbbbbb");

        frame.add(n);
        frame.setSize(220,100);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    public void paintComponent(Graphics g){
        for(int i=0;i<lista.size();i++){
            double x=((lista.get(i).x-75)*10000)-5000;
            double y=((lista.get(i).y-6)*10000)-3000;
            int xx=(int)x*10000;
            int yy=(int)x*10000;
  
            if(lista.get(i).B==true){
                g.setColor(Color.red);
                g.fillOval(920-(int)x,640-(int)y,2,2);
            }else{
                g.setColor(Color.blue);
                g.fillOval(920-(int)x,640-(int)y,2,2);
            }
        }
    }
}
